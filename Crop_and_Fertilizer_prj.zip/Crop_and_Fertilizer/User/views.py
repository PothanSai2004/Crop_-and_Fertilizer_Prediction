from django.shortcuts import render, redirect
from django.contrib.auth.models import User, auth
from django.contrib import messages

# Create your views here.
def home(request):
    return render(request,"index.html")

def about(request):
    return render(request,"about.html")

def blog(request):
    return render(request,"blog.html")

def contact(request):
    return render(request,"contact.html")

def products(request):
    return render(request,"products.html")

# def register(request):
#     if request.method=="POST":
#         f=request.POST['fname']
#         l=request.POST['lname']
#         u=request.POST['uname']
#         e=request.POST['email']
#         p1=request.POST['psw']
#         p2=request.POST['psw-repeat']

#         # if p1 == p2:
#         #     if User.objects.filter(u=u).exists():
#         #         messages.info(request,'Username already exists !!!!')
#         #         return render(request,'register.html')
#         #     elif User.objects.filter(e==e).exists():
#         #         messages.info(request,'Email already exists !!!')
#         #         return render(request,'register.html')
#         #     else:

#         #stores value to database
#         user=User.objects.create_user(first_name=f, last_name=l, username=u, email=e, password=p2)
#         user.save()
#         print('User Created')
#         #return redirect('loginpage')
#         return render(request,'login.html')
        
#         # else:
#         #     messages.info(request,'Invalid Credentials !!!')
#         #     return render(request,'register.html')
        
#         # return redirect('/')
#     else:
#         return render(request,"register.html")
#     # return render(request,"request.html")
# =====================================
def register(request):
    if request.method=="POST":
        f=request.POST['fname']
        l=request.POST['lname']
        u=request.POST['uname']
        e=request.POST['email']
        p1=request.POST['psw']
        p2=request.POST['psw-repeat']
        if p1==p2:
            if User.objects.filter(username=u).exists():
                messages.info(request,"Username Exists")
                return render(request,"register.html")
            elif User.objects.filter(email=e).exists():
                messages.info(request,"Email Exists")
                return render(request,"register.html")
            else:
                #Store value in database
            #table key name=variable to store the data
                user=User.objects.create_user(first_name=f,last_name=l,username=u,
        email=e,password=p2)
                user.save()
                return redirect('/')
        else:
            messages.info(request,"Password Not matching")
            return render(request,"register.html")
    else:
        return render(request,"register.html")
    return render(request,"register.html")
# ==================================
# def login(request):
#     if request.method=="POST":
#         u=request.POST['uname']
#         p=request.POST['psw']
#         e=request.POST['email']
#         user=auth.authenticate(username=u, email=e, password=p)
#         if user is not None:
#             # auth.login(request,user)
#             return redirect('homepage')
#         # else:
#         #     # messages.into(request,'Invalid Credentials !!!')
#         #     return render(request,"login.html")
#     else:
#         return render(request,"login.html") 

# ==================================
def login(request):
    if request.method=="POST":
        u=request.POST['uname']
        p=request.POST['psw']
        user=auth.authenticate(username=u,password=p)
        if user is not None:
            auth.login(request,user)
            return redirect('homepage')
        else:
            messages.info(request,"Invalid Credentials")
            return render(request,"login.html")
    return render(request,"login.html")

def logout(request):
    auth.logout(request)
    return redirect('/')

import matplotlib.pyplot as plt
import io
import base64

def crop(request):
    return render(request, "crop.html")

#---------------Crop Prediction-------------------
def prediction(request):
    if request.method == "POST":
        n=float(request.POST['nlvl'])
        p=float(request.POST['plvl'])
        k=float(request.POST['klvl'])
        temp=float(request.POST['temp'])
        humi=float(request.POST['humi'])
        ph=float(request.POST['ph'])
        rain=float(request.POST['rain'])
        import pandas as pd 
        df=pd.read_csv(r"static/dataset/Crop_recommendation.csv")
        print(df.isnull().sum())
        print(df.dropna(inplace=True))
        plt.hist(df['label'])
        plt.xlabel('Label')
        plt.ylabel('Count')
        plt.title('Label Distribution')
        # Save the plot as a PNG file
        buf = io.BytesIO()
        plt.savefig(buf, format='png')
        plt.close()
        buf.seek(0)
        plot_data = base64.b64encode(buf.read()).decode('utf-8')

        X_train=df[["N","P","K","temperature","humidity","ph","rainfall"]]
        y_train=df[["label"]]
        from sklearn.ensemble import RandomForestClassifier
        r=RandomForestClassifier()
        r.fit(X_train,y_train)
        import numpy as np 
        data=np.array([[n,p,k,temp,humi,ph,rain]],dtype=float)
        pred_outcome=r.predict(data)
        print(pred_outcome)
        
        return render(request, "prediction.html", {
            "nlvl": n,
            "plvl": p,
            "klvl": k,
            "temp": temp,
            "humi": humi,
            "ph": ph,
            "rain": rain,
            "output": pred_outcome,
            "plot_data": plot_data
        })
    return render(request, "prediction.html")

def fertilizer(request):
    return render(request, "fertilizer.html")

#---------------Fertilizer Prediction-------------------
# def prediction_f(request):
#     if request.method == "POST":
#         temp=float(request.POST['temp'])
#         humi=float(request.POST['humi'])
#         mois=float(request.POST['mois'])
#         soil=float(request.POST['soil'])
#         crop=float(request.POST['crop'])
#         n=float(request.POST['nlvl'])
#         p=float(request.POST['plvl'])
#         k=float(request.POST['klvl'])
#         import pandas as pd 
#         df=pd.read_csv(r"static/dataset/Fertilizer Prediction.csv")
#         print(df.isnull().sum())
#         print(df.dropna(inplace=True))
#         plt.hist(df['Fertilizer Name'])
#         soil_dict={
#             'Loamy':1,
#             'Sandy':2,
#             'Clayey':3,
#             'Black':4,
#             'Red':5
#         }

#         crop_dict={
#             'Sugarcane':1,
#             'Cotton':2,
#             'Millets':3,
#             'Paddy':4,
#             'Pulses':5,
#             'Wheat':6,
#             'Tobacco':7,
#             'Barley':8,
#             'Oil seeds':9,
#             'Ground Nuts':10,
#             'Maize':11    
#         }
#         df['Soil_Num']=df['Soil Type'].map(soil_dict)
#         df['Crop_Num']=df['Crop Type'].map(crop_dict)
#         plt.xlabel('Fertilizer Name')
#         plt.ylabel('Count')
#         plt.title('Fertilizer Name Distribution')
#         # Save the plot as a PNG file
#         buf = io.BytesIO()
#         plt.savefig(buf, format='png')
#         plt.close()
#         buf.seek(0)
#         plot_data = base64.b64encode(buf.read()).decode('utf-8')

#         X_train=df[["Temparature","Humidity ","Moisture","Soil_Num","Crop_Num","Nitrogen","Potassium","Phosphorous"]]
#         y_train=df[["Fertilizer Name"]]
#         from sklearn.tree import DecisionTreeClassifier
#         r=DecisionTreeClassifier()
#         r.fit(X_train,y_train)
#         import numpy as np 
#         data=np.array([[temp,humi,mois,soil,crop,n,p,k]],dtype=float)
#         pred_outcome=r.predict(data)
#         print(pred_outcome)
        
#         return render(request, "prediction_f.html", {
#             "temp": temp,
#             "humi": humi,
#             "mois": mois,
#             "soil": soil,
#             "crop": crop,
#             "nlvl": n,
#             "plvl": p,
#             "klvl": k,
#             "output": pred_outcome,
#             "plot_data": plot_data
#         })
#     return render(request, "prediction_f.html")


import io
import base64
import matplotlib.pyplot as plt
import numpy as np
from django.contrib import messages
from django.shortcuts import render
from sklearn.tree import DecisionTreeClassifier

def prediction_f(request):
    if request.method == "POST":
        temp = float(request.POST.get("temp"))
        humi = float(request.POST.get("humi"))
        mois = float(request.POST.get("mois"))
        soil = request.POST.get("soil").capitalize()  # Convert to capitalize for consistent mapping
        crop = request.POST.get("crop")
        n = float(request.POST.get("nlvl"))
        p = float(request.POST.get("plvl"))
        k = float(request.POST.get("klvl"))

        soil_dict = {
            'Sandy': 1,
            'Loamy': 2,
            'Clayey': 3,
            'Black': 4,
            'Red': 5
        }

        crop_dict = {
            'Sugarcane': 1,
            'Cotton': 2,
            'Millets': 3,
            'Paddy': 4,
            'Pulses': 5,
            'Wheat': 6,
            'Tobacco': 7,
            'Barley': 8,
            'Oil seeds': 9,
            'Ground Nuts': 10,
            'Maize': 11
        }
        import pandas as pd
        df = pd.read_csv(r"static/dataset/Fertilizer Prediction.csv")

        df['Soil_Num'] = df['Soil Type'].map(soil_dict)
        df['Crop_Num'] = df['Crop Type'].map(crop_dict)

        plt.xlabel('Fertilizer Name')
        plt.ylabel('Count')
        plt.title('Fertilizer Name Distribution')

        buf = io.BytesIO()
        plt.savefig(buf, format='png')
        plt.close()
        buf.seek(0)
        plot_data = base64.b64encode(buf.read()).decode('utf-8')

        X_train = df[["Temparature", "Humidity ", "Moisture", "Soil_Num", "Crop_Num", "Nitrogen", "Potassium", "Phosphorous"]]
        y_train = df["Fertilizer Name"]

        r = DecisionTreeClassifier()
        r.fit(X_train, y_train)

        data = np.array([[temp, humi, mois, soil_dict[soil], crop_dict[crop], n, p, k]], dtype=float)
        pred_outcome = r.predict(data)

        return render(request, "prediction_f.html", {
            "temp": temp,
            "humi": humi,
            "mois": mois,
            "soil": soil,
            "crop": crop,
            "nlvl": n,
            "plvl": p,
            "klvl": k,
            "output": pred_outcome,
            "plot_data": plot_data
        })

    return render(request, "prediction_f.html")