from django.urls import path
from .import views
urlpatterns = [
    path('home',views.home,name='homepage'),
    path('about',views.about,name='aboutpage'),
    path('blog',views.blog,name='blogpage'),
    path('contact',views.contact,name='contactpage'),
    path('products',views.products,name='productspage'),
    path('register',views.register,name='registerpage'),
    path('',views.login,name='loginpage'),
    path('logout',views.logout,name='logout'),
    path('crop',views.crop,name='croppage'),
    path('prediction',views.prediction,name='prediction'),
    path('fertilizer',views.fertilizer,name='fertilizerepage'),
    path('prediction_f',views.prediction_f,name='prediction_f')
]